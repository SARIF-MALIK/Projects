const express = require('express')
const app = express()
const path = require('path')

let arr =[
    {
    id: 0,
    author: "abhishek",
    comment: "backend is easy"
},
{
    id: 1,
    author: "rahul",
    comment: "backend is so easy"
},
{
    id: 2,
    author: "ravi",
    comment: "backend is hard"
},
{
    id: 3,
    author: "superman",
    comment: "backend is nothing"
}
]

app.set('view engine', 'ejs')
app.set('views', path.join(__dirname, 'views'))
app.use(express.static(path.join(__dirname, 'public')))

//root route
app.get('/', (req,res)=>{
    res.send('root route')
})

// to show all the blogs

app.get('/blogs', (req,res) =>{
    res.render('index', {arr} )
})

// to show new blog page/form

app.get('/blogs/new', (req,res) =>{
    res.render('new' )
    console.log('new blog page');
})

// to actually add into the db

app.post('/blogs', (req, res) =>{
    //console.log(req.body)
    let {author , comments} = req.body;
    comments.push({author, comments, id: comments.length})
    req.send(req.body)
})

app.listen (8080, ()=>{
    console.log("server connected");
})